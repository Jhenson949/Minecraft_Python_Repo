cansOfTunaPerCat = 4
cats = input("How many cats do you have? ")
cats = input(cats)
dailyTunaEaten = cats * cansOfTunaPerCat
